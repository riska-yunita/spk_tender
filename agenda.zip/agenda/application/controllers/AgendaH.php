<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AgendaH extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Harian_model');
	}


	public function data()
	{
		$data['title'] = 'Laporan Harian Transmisi Sandi';

		$config['base_url'] = base_url('AgendaH/data');
		$config['total_rows'] = $this->db->count_all('laporan_harian');
		$config['per_page'] = 20;
		$config['uri_segment'] = 3;
		$choice = $config["total_rows"] / $config['per_page'];
		$config["num_links"] = floor($choice);

		$config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-left">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tagl_close']  = '</span>Next</li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tagl_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tagl_close']  = '</span></li>';

		$this->pagination->initialize($config);

		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

		$data['laporan_harian'] = $this->Harian_model->get_pagedata($config["per_page"], $data['page'])->result();
		$data['pagination'] = $this->pagination->create_links();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('harian/data', $data); 
		$this->load->view('templates/footer');

	}

	public function input()
	{
		$data['title'] = 'Laporan Harian Transmisi Sandi';

		$data['laporan_harian'] = $this->db->get('laporan_harian')->result_array();
		
		$this->form_validation->set_rules('no','No.','required');
		$this->form_validation->set_rules('jam','Jam','required');
		$this->form_validation->set_rules('dari','Dari','required');
		$this->form_validation->set_rules('untuk','Untuk','required');
		$this->form_validation->set_rules('nomorsurat','Nomor Surat','required');
		$this->form_validation->set_rules('operator','Operator','required');
		$this->form_validation->set_rules('ket','Keterangan');

			if($this->form_validation->run() == false){
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('harian/input', $data); 
		$this->load->view('templates/footer');
		} else {
			$data = [
			'no' 	 => $this->input->post('no'),
			'jam' 	 => $this->input->post('jam'),
			'dari' 		 => $this->input->post('dari'),
			'untuk' 	 => $this->input->post('untuk'),
			'nomorsurat' 		 => $this->input->post('nomorsurat'),
			'operator' 		 => $this->input->post('operator'),
			'ket' 		 => $this->input->post('ket')
			];
			$this->db->insert('laporan_harian', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Data Added!</div>');
					redirect('agendah/data');	
		}
	}

	public function edit($no)
	{
		$data['title'] = 'Laporan Harian Transmisi Sandi';

		$where = array('no' => $no);
		$data['laporan_harian'] = $this->Harian_model->editData($where, 'laporan_harian')->result();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('harian/edit', $data); 
		$this->load->view('templates/footer');
	}

	public function update()
	{
			$no 	= $this->input->post('no');
			$jam = $this->input->post('jam');
			$dari = $this->input->post('dari');
			$untuk = $this->input->post('untuk');
			$nomorsurat = $this->input->post('nomorsurat');
			$operator = $this->input->post('operator');
			$ket = $this->input->post('ket');

			$data = array(
				'no'		=> $no,
				'jam'	=> $jam,
				'dari'		=> $dari,
				'untuk'		=> $untuk,
				'nomorsurat'		=> $nomorsurat,
				'operator'		=> $operator,
				'ket'		=> $ket
 			);

 			$where = array(
 				'no' => $no
 			);

 			$this->Harian_model->updateData($where, $data, 'harian');
 			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Edited!</div>');
					redirect('agendah/data');

	}

	public function delete($no)
	{
		$where = array ('no' => $no);
		$this->Harian_model->deleteData($where, 'laporan_harian');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Deleted!</div>');
        redirect('agendah/data');	
	}

	public function search()
	{
		$data['title'] = 'Laporan Harian Transmisi Sandi';
		
		$keyword = $this->input->post('keyword');
		$data['laporan_harian'] = $this->Harian_model->get_keyword($keyword);
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('harian/datacari', $data); 
		$this->load->view('templates/footer');
	}

	public function print(){
		$data['laporan_harian'] = $this->db->get('laporan_harian')->result_array();
		$this->load->view('harian/print_agenda', $data);
	}

	public function pdf(){
		$this->load->library('dompdf_gen');

		$data['laporan_harian'] = $this->db->get('laporan_harian')->result_array();
		$this->load->view('harian/laporanpdf', $data);

		$paper_size = 'F4';
		$orientation = 'Portrait';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Lap_AgdSuratHarian.pdf", array('Attachement' =>0));
	}
}