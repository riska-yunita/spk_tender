<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AgendaK extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		$this->load->model('Keluar_model');
	}


	public function data()
	{
		$data['title'] = 'Agenda Surat Keluar';

		$config['base_url'] = base_url('AgendaK/data');
		$config['total_rows'] = $this->db->count_all('surat_keluar');
		$config['per_page'] = 20;
		$config['uri_segment'] = 3;
		$choice = $config["total_rows"] / $config['per_page'];
		$config["num_links"] = floor($choice);

		$config['first_link']       = 'First';
        $config['last_link']        = 'Last';
        $config['next_link']        = 'Next';
        $config['prev_link']        = 'Prev';
        $config['full_tag_open']    = '<div class="pagging text-center"><nav><ul class="pagination justify-content-left">';
        $config['full_tag_close']   = '</ul></nav></div>';
        $config['num_tag_open']     = '<li class="page-item"><span class="page-link">';
        $config['num_tag_close']    = '</span></li>';
        $config['cur_tag_open']     = '<li class="page-item active"><span class="page-link">';
        $config['cur_tag_close']    = '<span class="sr-only">(current)</span></span></li>';
        $config['next_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['next_tagl_close']  = '<span aria-hidden="true">&raquo;</span></span></li>';
        $config['prev_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['prev_tagl_close']  = '</span>Next</li>';
        $config['first_tag_open']   = '<li class="page-item"><span class="page-link">';
        $config['first_tagl_close'] = '</span></li>';
        $config['last_tag_open']    = '<li class="page-item"><span class="page-link">';
        $config['last_tagl_close']  = '</span></li>';

		$this->pagination->initialize($config);

		$data['page'] = ($this->uri->segment(3)) ? $this->uri->segment(3) : 0;

		$data['keluar'] = $this->Keluar_model->get_pagedata($config["per_page"], $data['page'])->result();
		$data['pagination'] = $this->pagination->create_links();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('keluar/data', $data); 
		$this->load->view('templates/footer');

	}

	public function input()
	{
		$data['title'] = 'Agenda Surat Keluar';

		$data['keluar'] = $this->db->get('surat_keluar')->result_array();
		
		$this->form_validation->set_rules('noreg','No. Reg','required');
		$this->form_validation->set_rules('nosurat','Nomor SUrat','required');
		$this->form_validation->set_rules('dari','Dari','required');
		$this->form_validation->set_rules('untuk','Untuk','required');
		$this->form_validation->set_rules('hal','Perihal','required');
		$this->form_validation->set_rules('tgl','Tanggal','required');
		$this->form_validation->set_rules('disposisi','Tanggal Disposisi','required');
		$this->form_validation->set_rules('pengagenda','Pengagenda','required');
		$this->form_validation->set_rules('ket','Keterangan');

			if($this->form_validation->run() == false){
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('keluar/input', $data); 
		$this->load->view('templates/footer');
		} else {
			$data = [
			'noreg' 	 => $this->input->post('noreg'),
			'nosurat' 	 => $this->input->post('nosurat'),
			'dari' 		 => $this->input->post('dari'),
			'untuk' 	 => $this->input->post('untuk'),
			'hal' 		 => $this->input->post('hal'),
			'tgl' 		 => $this->input->post('tgl'),
			'disposisi'  => $this->input->post('disposisi'),
			'pengagenda' => $this->input->post('pengagenda'),
			'ket' 		 => $this->input->post('ket')
			];
			$this->db->insert('surat_keluar', $data);
			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">New Data Added!</div>');
					redirect('agendak/data');	
		}
	}

	public function edit($noreg)
	{
		$data['title'] = 'Agenda Surat Keluar';

		$where = array('noreg' => $noreg);
		$data['keluar'] = $this->Keluar_model->editData($where, 'surat_keluar')->result();

		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('keluar/edit', $data); 
		$this->load->view('templates/footer');
	}

	public function update()
	{
			$noreg 	= $this->input->post('noreg');
			$nosurat = $this->input->post('nosurat');
			$dari = $this->input->post('dari');
			$untuk = $this->input->post('untuk');
			$hal = $this->input->post('hal');
			$tgl = $this->input->post('tgl');
			$disposisi = $this->input->post('disposisi');
			$pengagenda = $this->input->post('pengagenda');
			$ket = $this->input->post('ket');

			$data = array(
				'noreg'		=> $noreg,
				'nosurat'	=> $nosurat,
				'dari'		=> $dari,
				'untuk'		=> $untuk,
				'hal'		=> $hal,
				'tgl'		=> $tgl,
				'disposisi'		=> $disposisi,
				'pengagenda'	=> $pengagenda,
				'ket'		=> $ket
 			);

 			$where = array(
 				'noreg' => $noreg
 			);

 			$this->Keluar_model->updateData($where, $data, 'surat_keluar');
 			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Edited!</div>');
					redirect('agendak/data');

	}

	public function delete($noreg)
	{
		$where = array ('noreg' => $noreg);
		$this->Keluar_model->deleteData($where, 'surat_keluar');
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Data Deleted!</div>');
        redirect('agendak/data');	
	}

	public function search()
	{
		$data['title'] = 'Surat Keluar';
		
		$keyword = $this->input->post('keyword');
		$data['keluar'] = $this->Keluar_model->get_keyword($keyword);
		$this->load->view('templates/header', $data);
		$this->load->view('templates/sidebar', $data);
		$this->load->view('templates/topbar', $data);
		$this->load->view('keluar/datacari', $data); 
		$this->load->view('templates/footer');
	}

	public function print(){
		$data['keluar'] = $this->db->get('surat_keluar')->result_array();
		$this->load->view('keluar/print_agenda', $data);
	}

	public function pdf(){
		$this->load->library('dompdf_gen');

		$data['keluar'] = $this->db->get('surat_keluar')->result_array();
		$this->load->view('keluar/laporanpdf', $data);

		$paper_size = 'F4';
		$orientation = 'Landscape';
		$html = $this->output->get_output();
		$this->dompdf->set_paper($paper_size, $orientation);

		$this->dompdf->load_html($html);
		$this->dompdf->render();
		$this->dompdf->stream("Lap_AgdSuratKeluar.pdf", array('Attachement' =>0));
	}

}

