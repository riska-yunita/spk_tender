<?php

class Masuk_model extends CI_Model
{

    public function deleteData($where)
    {
    	$this->db->where($where);
    	$this->db->delete('surat_masuk');
    }

    public function editData($where)
    {
    	return $this->db->get_where('surat_masuk', $where);
    }

    public function updateData($where, $data)
    {
    	$this->db->where($where);
    	$this->db->update('surat_masuk', $data);
    }

    public function get_keyword($keyword)
    {
    	$this->db->select('*');
    	$this->db->from('surat_masuk');
    	$this->db->like('noreg', $keyword);
    	$this->db->or_like('nosurat', $keyword);
    	$this->db->or_like('dari', $keyword);
    	$this->db->or_like('untuk', $keyword);
    	$this->db->or_like('hal', $keyword);
    	$this->db->or_like('tgl', $keyword);
    	$this->db->or_like('disposisi', $keyword);
    	$this->db->or_like('pengagenda', $keyword);
    	$this->db->or_like('ket', $keyword);
    	return $this->db->get()->result();
    }

    public function get_data()
    {
    	$this->db->select('*');
    	$this->db->from('surat_masuk');
    	return $this->db->get()->result();
    }

    public function get_pagedata($limit, $start)
    {
        $query = $this->db->get('surat_masuk', $limit, $start);
        return $query;
    }
}

