<?php

class Harian_model extends CI_Model
{

    public function deleteData($where)
    {
    	$this->db->where($where);
    	$this->db->delete('laporan_harian');
    }

    public function editData($where)
    {
    	return $this->db->get_where('laporan_harian', $where);
    }

    public function updateData($where, $data)
    {
    	$this->db->where($where);
    	$this->db->update('laporan_harian', $data);
    }

    public function get_keyword($keyword)
    {
    	$this->db->select('*');
    	$this->db->from('laporan_harian');
    	$this->db->like('no', $keyword);
    	$this->db->or_like('jam', $keyword);
    	$this->db->or_like('dari', $keyword);
    	$this->db->or_like('untuk', $keyword);
    	$this->db->or_like('nomorsurat', $keyword);
    	$this->db->or_like('operator', $keyword);
    	$this->db->or_like('ket', $keyword);
    	return $this->db->get()->result();
    }

    public function get_data()
    {
    	$this->db->select('*');
    	$this->db->from('laporan_harian');
    	return $this->db->get()->result();
    }

    public function get_pagedata($limit, $start)
    {
        $query = $this->db->get('laporan_harian', $limit, $start);
        return $query;
    }
}

