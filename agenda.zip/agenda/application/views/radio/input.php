<!DOCTYPE html>

<html>
<head>
<title></title>

<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.css">
<script src="jquery-ui-1.12.1.custom/external/jquery/jquery.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.theme.css">

<script>
$(document).ready(function(){
$("#tanggal").datepicker({
});
});

$(document).ready(function(){
$("#waktu").datetimepicker({
  datepicker:false, 
  format:'H:i'
});
});
</script>
</head>
<body>

 <div class="container-fluid">

          <!-- Page Heading -->
          <br><h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
          <hr>
          <div class="row">
            <div class="col-lg-10">

              <?= $this->session->flashdata('message'); ?>

          <div class="card mb-3">
            <div class="card-header py-3">
              <h5 class="m-0 font-weight-bold text-primary">Input Data</h5>
            </div>
          <div class="card-body">

            <?php echo form_open_multipart('agendar/input');?>

             <div class="form-group row">
                <label for="noreg" class="col-sm-2 col-form-label">No. Reg*</label>
                <div class="col-sm-10">
                  <input type="text" style="width:150px;" class="form-control" id="noreg" name="noreg" placeholder="Nomor Registrasi">
                  <?= form_error('noreg', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="nosurat" class="col-sm-2 col-form-label">Nomor Surat*</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="nosurat" name="nosurat" placeholder="Nomor Surat">
                  <?= form_error('nosurat', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="dari" class="col-sm-2 col-form-label">Dari*</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="dari" name="dari" placeholder="Dari">
                  <?= form_error('dari', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="untuk" class="col-sm-2 col-form-label">Untuk*</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="untuk" name="untuk" placeholder="Untuk">
                  <?= form_error('untuk', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="hal" class="col-sm-2 col-form-label">Perihal*</label>
                <div class="col-sm-10">
                  <textarea type="text" style="width:400px; height:100px" class="form-control" id="hal" name="hal" placeholder="Perihal"></textarea>
                  <?= form_error('hal', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="tgl" class="col-sm-2 col-form-label">Tanggal*</label>
                <div class="col-sm-10">
                  <input type="date" style="width:400px;" class="form-control" id="tgl" name="tgl">
                  <?= form_error('tgl', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="disposisi" class="col-sm-2 col-form-label">Tanggal Disposisi*</label>
                <div class="col-sm-10">
                  <input type="date" style="width:400px;" class="form-control" id="disposisi" name="disposisi">
                  <?= form_error('disposisi', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="pengagenda" class="col-sm-2 col-form-label">Pengagenda*</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="pengagenda" name="pengagenda" placeholder="Pengagenda">
                  <?= form_error('pengagenda', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="ket" class="col-sm-2 col-form-label">Keterangan</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="ket" name="ket" placeholder="Keterangan">
                  <?= form_error('ket', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group" style="text-align:center">
              <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Data</button>
            </div>
              <?php echo form_close(); ?>
            </div>
          <div class="card-footer small text-muted">
            *Required Fields
          </div>
          </div>
        </div>
      </div>
        </div>
        <!-- /.container-fluid -->

      </div>

</body>
</html>