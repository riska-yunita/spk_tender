<!DOCTYPE html>
<html><head>
	<title></title>
</head><body>

<h2 style="text-align: center">LAPORAN AGENDA TRANSMISI SURAT RADIOGRAM</h2><br><br>

	<table border="1" style="border-collapse:collapse;">
		<tr>
            <th>No. Reg</th>
            <th>Nomor Surat</th>
            <th>Dari</th>
            <th>Untuk</th>
            <th>Perihal</th>
            <th>Tanggal</th>
            <th>Disposisi</th>
            <th>Pengagenda</th>
            <th>Ket.</th>
		</tr>

  	<?php $i = 1; ?>
    <?php foreach ($radiogram as $rdo) :?>

    <tr>
    <td><?= $rdo['noreg']; ?></td>
    <td><?= $rdo['nosurat']; ?></td>
    <td><?= $rdo['dari']; ?></td>
    <td><?= $rdo['untuk']; ?></td>
    <td><?= $rdo['hal']; ?></td>
    <td><?= $rdo['tgl']; ?></td>
    <td><?= $rdo['disposisi']; ?></td>
    <td><?= $rdo['pengagenda']; ?></td>
    <td><?= $rdo['ket']; ?></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
</table>
</body></html>
 