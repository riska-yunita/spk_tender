<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h2 style="text-align: center">LAPORAN AGENDA SURAT MASUK</h2><br>

	<table border="1" style="border-collapse:collapse;">
		<tr>
			<th>No. Reg</th>
			<th>Nomor Surat</th>
			<th>Dari</th>
			<th>Untuk</th>
			<th>Perihal</th>
			<th>Tanggal</th>
            <th>Disposisi</th>
			<th>Pengagenda</th>
			<th>Ket.</th>
		</tr>

  	<?php $i = 1; ?>
    <?php foreach ($masuk as $msk) :?>

    <tr>
    <td><?= $msk['noreg']; ?></td>
    <td><?= $msk['nosurat']; ?></td>
    <td><?= $msk['dari']; ?></td>
    <td><?= $msk['untuk']; ?></td>
    <td><?= $msk['hal']; ?></td>
    <td><?= $msk['tgl']; ?></td>
    <td><?= $msk['disposisi']; ?></td>
    <td><?= $msk['pengagenda']; ?></td>
    <td><?= $msk['ket']; ?></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>

</table>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html>
 