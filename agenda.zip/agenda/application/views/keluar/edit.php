      <!DOCTYPE html>

<html>
<head>
<title></title>

<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.css">
<script src="jquery-ui-1.12.1.custom/external/jquery/jquery.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.theme.css">

<script>
$(document).ready(function(){
$("#tanggal").datepicker({
});
});

$(document).ready(function(){
$("#waktu").datetimepicker({
  datepicker:false, 
  format:'H:i'
});
});
</script>
</head>
<body>

 <div class="container-fluid">

          <!-- Page Heading -->
          <br><h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
          <hr>
          <div class="row">
            <div class="col-lg-10">

              <?= $this->session->flashdata('message'); ?>

          <div class="card mb-3">
            <div class="card-header py-3">
              <h5 class="m-0 font-weight-bold text-primary">Edit Data</h5>
            </div>
          <div class="card-body">
                <?php foreach ($keluar as $klr) :?>
          <form action="<?php echo base_url().'agendak/update'; ?>" method="post">
             <div class="form-group row">
                <label for="noreg" class="col-sm-2 col-form-label">No. Reg</label>
                <div class="col-sm-10">
                  <input type="text" style="width:150px;" class="form-control" id="noreg" name="noreg" value="<?php echo $klr->noreg ?>">
                  <?= form_error('noreg', '<small class="text-danger pl-3">', '</small>'); ?>
                </div>
              </div>

              <div class="form-group row">
                <label for="nosurat" class="col-sm-2 col-form-label">Nomor Surat</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="nosurat" name="nosurat" value="<?php echo $klr->nosurat ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="dari" class="col-sm-2 col-form-label">Dari</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="dari" name="dari" value="<?php echo $klr->dari ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="untuk" class="col-sm-2 col-form-label">Untuk</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="untuk" name="untuk" value="<?php echo $klr->untuk ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="hal" class="col-sm-2 col-form-label">Perihal</label>
                <div class="col-sm-10">
                  <textarea type="text" style="width:400px; height:100px" class="form-control" id="hal" name="hal"><?php echo $klr->hal ?></textarea>
                </div>
              </div>

              <div class="form-group row">
                <label for="tgl" class="col-sm-2 col-form-label">Tanggal</label>
                <div class="col-sm-10">
                  <input type="date" style="width:400px;" class="form-control" id="tgl" name="tgl" value="<?php echo $klr->tgl ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="disposisi" class="col-sm-2 col-form-label">Tanggal Disposisi</label>
                <div class="col-sm-10">
                  <input type="date" style="width:400px;" class="form-control" id="disposisi" name="disposisi" value="<?php echo $klr->disposisi ?>">
                </div>
              </div>


              <div class="form-group row">
                <label for="pengagenda" class="col-sm-2 col-form-label">Pengagenda</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="pengagenda" name="pengagenda" value="<?php echo $klr->pengagenda ?>">
                </div>
              </div>

              <div class="form-group row">
                <label for="ket" class="col-sm-2 col-form-label">Keterangan</label>
                <div class="col-sm-10">
                  <input type="text" style="width:400px;" class="form-control" id="ket" name="ket" value="<?php echo $klr->ket ?>">
                </div>
              </div>

              <div class="form-group" style="text-align:center">
              <button type="submit" class="btn btn-primary"><i class="fas fa-edit"></i> Edit</button>
              <button type="reset" class="btn btn-danger"><i class="fas fa-backspace"></i> Reset</button>
            </div>
              </form>
            <?php endforeach; ?>
            </div>
          <div class="card-footer small text-muted">
          </div>
          </div>
        </div>
      </div>
        </div>
        <!-- /.container-fluid -->

      </div>

</body>
</html>

