<!DOCTYPE html>
<html><head>
	<title></title>
</head><body>

<h2 style="text-align: center">LAPORAN AGENDA TRANSMISI SURAT KELUAR</h2><br><br>

	<table border="1" style="border-collapse:collapse;">
		<tr>
            <th>No. Reg</th>
            <th>Nomor Surat</th>
            <th>Dari</th>
            <th>Untuk</th>
            <th>Perihal</th>
            <th>Tanggal</th>
            <th>Disposisi</th>
            <th>Pengagenda</th>
            <th>Ket.</th>
		</tr>

  	<?php $i = 1; ?>
    <?php foreach ($keluar as $klr) :?>

    <tr>
    <td><?= $klr['noreg']; ?></td>
    <td><?= $klr['nosurat']; ?></td>
    <td><?= $klr['dari']; ?></td>
    <td><?= $klr['untuk']; ?></td>
    <td><?= $klr['hal']; ?></td>
    <td><?= $klr['tgl']; ?></td>
    <td><?= $klr['disposisi']; ?></td>
    <td><?= $klr['pengagenda']; ?></td>
    <td><?= $klr['ket']; ?></td>
    </tr>
    <?php $i++; ?>
    <?php endforeach; ?>
</table>
</body></html>
 