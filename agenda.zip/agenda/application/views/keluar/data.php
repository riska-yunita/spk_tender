        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br><h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
          <hr>
              <div class="row">
          <div class="col-lg">

            <?= $this->session->flashdata('message'); ?>

            <a href="<?= base_url('agendak/input'); ?>" class="btn btn-primary mb-3" ><i class="fa fa-plus"></i> Add New Data</a>

            <a href="<?= base_url('agendak/print');?>" class="btn btn-danger mb-3"><i class="fa fa-print"></i> Print</a>

            <a href="<?= base_url('agendak/pdf');?>" class="btn btn-warning mb-3"><i class="fa fa-file-pdf"></i> Export to PDF</a>

              <form class="form-inline float-right" action="<?= base_url('agendak/search'); ?>" method="post">
                <input type="text" name="keyword" class="form-control" placeholder="Search For...">
                <button type="submit" class="btn btn-success"><i class="fas fa-search"></i></button>
              </form>

            <div class="card shadow mb-4">
            <div class="card-header py-3">
              <h5 class="m-0 font-weight-bold text-primary">Agenda Transmisi</h5>
            </div>

            <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <!--Tampilkan pagination-->
                        <?php echo $pagination; ?>
                    </div>
                  </div>
              <div class="table-responsive">
              <table class="table table-hover">

  <thead>
    <tr>
      <th scope="col">No. Reg</th>
      <th scope="col">Nomor Surat</th>
      <th scope="col">Dari</th>
      <th scope="col">Untuk</th>
      <th scope="col">Perihal</th>
      <th scope="col">Tanggal</th>
      <th scope="col">Tanggal Disposisi</th>
      <th scope="col">Pengagenda</th>
      <th scope="col">Ket.</th>



    </tr>
  </thead>
  <tbody>
    <?php foreach ($keluar as $klr) :?>

    <tr>
      <td><?= $klr->noreg; ?></td>
      <td><?= $klr->nosurat; ?></td>
      <td><?= $klr->dari; ?></td>
      <td><?= $klr->untuk; ?></td>
      <td><?= $klr->hal; ?></td>
      <td><?= $klr->tgl; ?></td>
      <td><?= $klr->disposisi; ?></td>
      <td><?= $klr->pengagenda; ?></td>
      <td><?= $klr->ket; ?></td>
      <td>
        <?php echo anchor('agendak/edit/'.$klr->noreg, '<div class="btn btn-primary btn-sm"><i class="fas fa-fw fa-edit"></i>Edit</div>') ?>
        </td>
      <td onclick="javascript: return confirm('Are you sure to delete this data?')">
        <?php echo anchor('agendak/delete/'.$klr->noreg, '<div class="btn btn-danger btn-sm"><i class="fas fa-fw fa-trash"></i> Delete</div>') ?>
        </td>
    </tr>
  <?php endforeach; ?>
  </tbody>
</table>
</div>
</div>
</div>


            </div>
          </div>
          
        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->