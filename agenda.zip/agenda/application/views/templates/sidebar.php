    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-dark accordion bg-gradient-info" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center mb-4" href="#">
        <div class="sidebar-brand-icon">
          <i class="fas fa-paper-plane"></i>
        </div>
        <div class="sidebar-brand-text mx-3"><br>AGENDA SURAT TRANSMISI</div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- QUERY MENU -->
      <li class="nav-item">
        <a class="nav-link" href="<?= base_url('admin/index') ?>">
            <i class="fas fa-fw fa-home"></i>
            <span>Halaman Awal</span>
        </a>
    </li>

    <li>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('agenda/data') ?>">
            <i class="fas fa-fw fa-envelope"></i>
            <span>Agenda Surat Masuk</span>
        </a>
    </li>

    <li>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('agendak/data') ?>">
            <i class="fas fa-fw fa-envelope-open"></i>
            <span>Agenda Surat Keluar</span>
        </a>
    </li>

    <li>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('agendar/data') ?>">
            <i class="fas fa-fw fa-envelope-open-text"></i>
            <span>Agenda Surat Radiogram</span>
        </a>
    </li>

    <li>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('agendah/data') ?>">
            <i class="fas fa-fw fa-envelope-open-text"></i>
            <span>Laporan Harian Transmisi</span>
        </a>
    </li>
   
    <li>
        <li class="nav-item">
        <a class="nav-link" href="<?= base_url('#') ?>">
            <i class="fas fa-fw fa-chart-bar"></i>
            <span>Charts</span>
        </a>
    </li>

    </ul>