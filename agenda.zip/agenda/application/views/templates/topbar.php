<div id="content-wrapper" class="d-flex flex-column">

      <!-- Main Content -->
      <div id="content">

<nav class="navbar navbar-light" style="background-color: #e3f2fd;">
<div class="mx-auto" style="width: 1000px; height: 250px">

	<center><p class="font-weight-bolder" style="font-size: 30px"><br><img style="width: 70px" src="<?php echo base_url();?>assets/img/kominfo.png"><br>DINAS KOMUNIKASI DAN INFORMATIKA<br>SEKSI PERSANDIAN </p></center>
</div>
</nav>



