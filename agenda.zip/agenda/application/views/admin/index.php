
        <!-- Begin Page Content -->
        <div class="container-fluid">

          <!-- Page Heading -->
          <br><h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
          <hr>
            <center><a href="<?= base_url('Agenda/data'); ?>" class="btn btn-primary mb-3" ><i class="fa fa-envelope"></i> SURAT MASUK</a>
            <a href="<?= base_url('AgendaK/data');?>" class="btn btn-danger mb-3"><i class="fa fa-envelope-open"></i> SURAT KELUAR</a>
            <a href="<?= base_url('AgendaR/data');?>" class="btn btn-warning mb-3"><i class="fa fa-envelope-open-text"></i> RADIOGRAM</a>
            <a href="<?= base_url('AgendaH/data'); ?>" class="btn btn-primary mb-3" ><i class="fa fa-envelope"></i> LAPORAN HARIAN TRANSMISI SANDI</a><center><br><br><br><br>

			<script type="text/javascript">
			 window.onload = function() { jam(); }

			 function jam() {
			  var e = document.getElementById('jam'),
			  d = new Date(), h, m, s;
			  h = d.getHours();
			  m = set(d.getMinutes());
			  s = set(d.getSeconds());

			  e.innerHTML = h +':'+ m +':'+ s;

			  setTimeout('jam()', 1000);
			 }

			 function set(e) {
			  e = e < 10 ? '0'+ e : e;
			  return e;
			 }
			</script>
			</head>
			<body>
			<center>
			<h3 style="font-size: 100px; font-family: arial; color:#FFF; background:deepskyblue" id="jam"></h3>
			</center>
			</body>

        </div>
        <!-- /.container-fluid -->

      </div>
      <!-- End of Main Content -->