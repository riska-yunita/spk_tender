<!DOCTYPE html>

<html>
<head>
<title></title>

<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.css">
<script src="jquery-ui-1.12.1.custom/external/jquery/jquery.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.js"></script>
<script src="jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="jquery-ui-1.12.1.custom/jquery-ui.theme.css">

<script>
$(document).ready(function(){
$("#tanggal").datepicker({
});
});

$(document).ready(function(){
$("#waktu").datetimepicker({
  datepicker:false, 
  format:'H:i'
});
});
</script>
</head>
<body>

 <div class="container-fluid" style="margin-left: 350px";>

         
          <div class="row" >
            <div class="col-lg-7">  
              <br>
              <div class="card mb-2">
                <div class="card-header py-3">
                  <h5 class="m-0 font-weight-bold text-primary">Masukkan Username dan Password</h5>
                </div>
                <div class="card-body">
                  <?php echo form_open_multipart('admin/login');?>
                    <div class="form-group row">
                      <label for="username" class="col-sm-2 col-form-label">Username</label>
                      <div class="col-sm-10">
                        <input type="text" style="width:180px;" class="form-control" id="username" name="username" placeholder="Masukkan Username">
                        <?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
                      </div>
                    </div>

                    <div class="form-group row" >
                      <label for="password" class="col-sm-2 col-form-label">Password</label>
                      <div class="col-sm-10"">
                        <input type="text" style="width:180px;" class="form-control" id="password" name="password" placeholder="Masukkan Password">
                        <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                      </div>
                    </div>
                    
                    <div class="form-group" >
                      <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Login</button>
                    </div>
                  <?php echo form_close(); ?>
                </div>
              </div>
            </div>
          </div>
      
        <!-- /.container-fluid -->

      </div>

</body>
</html>