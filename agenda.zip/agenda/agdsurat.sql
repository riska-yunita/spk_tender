-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Feb 2023 pada 11.35
-- Versi server: 10.1.36-MariaDB
-- Versi PHP: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `agdsurat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `laporan_harian`
--

CREATE TABLE `laporan_harian` (
  `no` int(100) NOT NULL,
  `tgl` date NOT NULL,
  `jam` time NOT NULL,
  `dari` varchar(500) NOT NULL,
  `untuk` varchar(500) NOT NULL,
  `nomorsurat` varchar(500) NOT NULL,
  `operator` varchar(500) NOT NULL,
  `ket` varchar(900) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `radiogram`
--

CREATE TABLE `radiogram` (
  `noreg` int(11) NOT NULL,
  `nosurat` varchar(128) NOT NULL,
  `dari` varchar(128) NOT NULL,
  `untuk` varchar(128) NOT NULL,
  `hal` varchar(256) NOT NULL,
  `tgl` date NOT NULL,
  `disposisi` date NOT NULL,
  `pengagenda` varchar(128) NOT NULL,
  `ket` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_keluar`
--

CREATE TABLE `surat_keluar` (
  `noreg` int(11) NOT NULL,
  `nosurat` varchar(128) DEFAULT NULL,
  `dari` varchar(128) DEFAULT NULL,
  `untuk` varchar(128) DEFAULT NULL,
  `hal` varchar(256) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `disposisi` date DEFAULT NULL,
  `pengagenda` varchar(128) DEFAULT NULL,
  `ket` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `surat_keluar`
--

INSERT INTO `surat_keluar` (`noreg`, `nosurat`, `dari`, `untuk`, `hal`, `tgl`, `disposisi`, `pengagenda`, `ket`) VALUES
(1, '045/033/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Penandatanganan Surat Pernyataan Melaksanakan Tugas', '2019-01-07', '2019-01-07', '', ''),
(2, '034/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo Kab/Kota Se-Sumsel', 'Penyampaian laporan Kerja Tahunan Bidang Persandian tahun 2019', '2019-01-08', '2019-01-08', '', ''),
(3, '800/064/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Badan Sertifikat Elektronik (BSrE) BSSN', 'Fasilitasi Tanda Tangan Digital dan Sertifikat Elektronik', '2019-01-14', '2019-01-14', '', ''),
(4, '02/Tiksan/04/2019', 'Kepala Seksi Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon Penandatanganan Berita Acara Serah Terima Barang', '2019-01-14', '2019-01-14', '', ''),
(5, '046/305/SJ', 'Mendagri', 'Gubernur', 'Mekanisme Pengusulan Peserta Diklat Sandi dan Diklat Teknis', '2019-01-15', '2019-01-15', '', ''),
(6, '07/Tiksan/04/2019', 'Kepala Seksi Persandian Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Penandatanganan Surat Pemberitahuan', '2019-01-16', '2019-01-16', '', ''),
(7, '06/Tiksan/04/2019', 'Kepala Seksi Persandian Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Penandatanganan Laporan Kegiatan Persandian 2018', '2019-01-16', '2019-01-16', '', ''),
(8, '045/086/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo Kab/Kota Se-Sumsel', 'Penyampaian Konfirmasi Penggunaan Email Sanapati', '2019-01-17', '2019-01-17', '', ''),
(9, '800/125/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'ASN Diskominfo yang di Tugaskan', 'Koordinasi dan Kelancaran Operasional Pemanfaatan Layanan Video Conference Kemendagri T.A 2019', '2019-01-17', '2019-01-17', '', ''),
(10, '08/04/TIKSAN/Diskominfo/2019', 'Kepala Seksi Persandian', 'Sekjen Kemendagri', 'Usulan Peserta Diklat Sandi Dan Diklat Teknis', '2019-01-18', '2019-01-18', '', ''),
(11, '046/114.1/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekjen Kemendagri', 'Usulan Peserta Diklat Teknis', '2019-01-24', '2019-01-24', '', ''),
(12, '045/112.2/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Penjelasan Layanan Video Conference Kemendagri T.A 2019', '2019-01-24', '2019-01-24', '', ''),
(13, '016/124/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala BSSN', 'Koordinasi terkait Kegiatan Security Assesment', '2019-01-29', '2019-01-29', '', ''),
(14, '034A/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo Kab/Kota Se-Sumsel', 'Penyampaian Laporan Kerja Tahunan Bidang Persandian Tahun 2018', '2019-02-07', '2019-02-07', '', ''),
(15, '016/148.1/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala BSSN', 'Mohon bantuan Giat Security Assesment/Pentest', '2019-02-07', '2019-02-07', '', ''),
(16, '001/Sandi/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Bidang TIK dan Persandian', 'Rekomendasi dan Persetujuan Pindah Tugas', '2019-02-11', '2019-02-11', '', ''),
(17, '10/Tiksan/04/2019', 'Kepala Seksi Persandian Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Persetujuan Pelaksanaan Monev dan Pembinaan ke Unit Teknis Persandian Kab/Kota Se-Sumsel', '2019-02-12', '2019-02-12', '', ''),
(18, '045/146.1/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Petunjuk Penempatan Perangkat Video Conference Kementrian Dalam Negeri TA 2019', '2019-02-13', '2019-02-13', '', ''),
(19, '045/167/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum dan HAM; Sekda Prov. Sumsel', 'Mohon koreksi draft Surat Edaran Gubernur', '2019-02-13', '2019-02-13', '', ''),
(20, '016/183/05/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'PT Telkom Indonesia', 'Mohon pemasangan Telepon Satelit di Pulau Maspari', '2019-02-18', '2019-02-18', '', ''),
(21, '016/198/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Bapak Manager Regional Account Management Sumbagsel', 'Mohon Bantuan Pemasangan Penguat Signal di Pulau Maspari Kabupaten OKI', '2019-02-20', '2019-02-20', '', ''),
(22, '045/242/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Penandatanganan Surat Permohonan Bantuan Pemasangan Penguat Signal', '2019-02-27', '2019-02-27', '', ''),
(23, '800/248/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'ASN Yang Ditugaskan', 'Surat Tugas', '2019-03-06', '2019-03-06', '', ''),
(24, '005/261/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo Kab/Kota Se-Sumsel', 'Undangan Rapat Penyiapan Sarana Video Conference', '2019-03-13', '2019-03-13', '', ''),
(25, '13/Tiksan/04/2019', 'Kepala Seksi Persandian Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Snack Sebanyak 35 Kotak', '2019-03-14', '2019-03-14', '', ''),
(26, '042/SE/DISKOMINFO/2019', 'Gubernur Sumsel', 'Daftar Terlampir', 'Penyampaian Radiogram Di Lingkungan Prov. Sumsel dan Kab/Kota Se-Sumsel Melalui Satu Pintu Yaitu Jaringan Komunikasi Sandi dan JarKom Sandi Internal E-Sanapati', '2019-03-15', '2019-03-15', '', ''),
(27, '-', 'Kadis Kominfo Prov. Sumsel', '-', 'Notulen Rapat Teknis Video Conference Se-Sumsel', '2019-03-18', '2019-03-18', '', ''),
(28, '045/202/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Wakil Gubernur Sumsel', 'Mohon Penandatanganan Surat Bantuan Pemasangan VSAT di Pulau Maspari', '2019-03-21', '2019-03-21', '', ''),
(29, '046/285/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo Kab, Muara Enim', 'Penyampaian Nama Petugas Kegiatan Kontra Penginderaan ', '2019-03-21', '2019-03-21', '', ''),
(30, '045/270.3/05/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Penandatanganan Surat Uji Coba Video Conference Ke Pemerintah Kab/Kota Se-Sumsel', '2019-04-04', '2019-04-04', '', ''),
(31, '005/282.1/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Umum dan Perlengkapan Setda Prov. Sumsel', 'Ijin Pemakaian Ruang Rapat Graha Bina Praja', '2019-04-09', '2019-04-09', '', ''),
(32, '120.1/318/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kadis Kominfo OKU Timur', 'Penyampaian Jadwal Kegiatan Kontra Penginderaan', '2019-04-18', '2019-04-18', '', ''),
(33, '17/Tiksan/04/2019', 'Kepala Seksi Persandian Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon Persetujuan dan Penandatanganan SPPD', '2019-04-23', '2019-04-23', '', ''),
(34, '22/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Asisten Administrasi dan Umum Setda Prov. Sumsel', 'Mohon penandatangan surat Undangan kegiatan Asistensi CSIRT ke Kabupaten/Kota se- Sumatera Selatan', '2019-05-06', '2019-05-06', '', ''),
(35, '-/04/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Daftar Terlampir', 'Surat Tugas kegiatan kontra penginderaan', '2019-05-06', '2019-05-06', '', ''),
(36, '21/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Asisten Administrasi dan Umum Setda Prov. Sumsel', 'Mohon pendatangan surat undangan kegiatan Asistensi CSIRT', '2019-05-06', '2019-05-06', '', ''),
(37, '005/376/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Biro Umum dan Perlengkapan Setda Prov. Sumsel', 'Ijin pemakaian ruang rapat Graha Bina Praja', '2019-05-08', '2019-05-08', '', ''),
(38, '016/1159/IV/2019', 'Gubernur', 'PT. Telkom Indonesia, Tbk', 'Pembangunan Menara Telekomunikasi', '2019-05-17', '2019-05-17', '', ''),
(39, '02/TIKSAN/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Biro Hukum dan HAM Setda Prov. Sumsel', 'Mohon Koreksi Draft Keputusan Gubernur', '2019-05-31', '2019-05-31', '', ''),
(40, '1764/BSSN/D3/KH.01.02/06/2019', 'Kadis Kominfo Prov. Sumsel', '-', 'Kegiatan Focus Group Discussion', '2019-06-17', '2019-06-17', '', ''),
(41, '045/489.1/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Biro Hukum dan HAM Setda Prov. Sumsel', 'Penyampaian Rancangan Keputusan Gubernur dan telah diperbaiki', '2019-06-19', '2019-06-19', '', ''),
(42, '045/549/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon persetujuan pemakaian gedung ex Santel Lantai 3', '2019-07-08', '2019-07-08', '', ''),
(43, '045/559/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Biro Hukum dan HAM Setda Prov. Sumsel', 'Mohon koreksi Rancangan Keputusan Gubernur', '2019-07-10', '2019-07-10', '', ''),
(44, '045/593/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon penandatangan surat Pernyataan Melaksanaan Tugas', '2019-07-19', '2019-07-19', '', ''),
(45, '045/594/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon penandatangan surat Pernyataan Melaksanakan Tugas', '2019-07-19', '2019-07-19', '', ''),
(46, '800/-/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Zabidi', 'Surat Tugas', '2019-07-24', '2019-07-24', '', ''),
(47, '800/-/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kasi TIK dan Persandian', 'Surat Tugas', '2019-07-24', '2019-07-24', '', ''),
(48, '045/614.1/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Biro Hukum Setda Prov. Sumsel', 'Penyampaian kembali Rancangan Keputusan Gubernur yang telah diparaf koordinasi', '2019-07-25', '2019-07-25', '', ''),
(49, '24/Tiksan/04/2019', 'Kabid TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon persetujuan SPPD ke Balai Sertifikat Elektronik (BSrE) Badan Siber dan Sandi Negara', '2019-07-25', '2019-07-25', '', ''),
(50, '045/615/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum dan HAM; Sekda Prov. Sumsel', 'Mohon Koreksi Rancangan Keputusan Gubernur', '2019-07-25', '2019-07-25', '', ''),
(51, '045/614.1/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum Sekda Prov. Sumsel', 'Penyampaian Kembali Rancangan Keputusan Gubernur Yang Telah Di Paraf Koordinasi', '2019-07-25', '2019-07-25', '', ''),
(52, '29/Tiksan/04/2019', 'Kepala Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon Persetujuan SPPD ke Balai Sertifikasi Elektronik (BSrE) Badan Siber dan Sandi Negara', '2019-07-25', '2019-07-25', '', ''),
(53, '045/468/04/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum Sekda Prov. Sumsel', 'Penyampaian Kembali Rancangan Keputusan Gubernur Yang Telah Di Paraf Koordinasi', '2019-08-07', '2019-08-07', '', ''),
(54, '25/Tiksan/04/2019', 'Kepala Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Perbaikan dan Service AC', '2019-08-08', '2019-08-08', '', ''),
(55, '800/682/04/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'ASN Yang Ditugaskan', 'Surat tugas', '2019-08-09', '2019-08-09', '', ''),
(56, '800/687.2/06/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', '-', 'Pembentukan Panitia Pelaksanaan Kegiatan Pameran Sriwijaya EXPO Prov. Sumsel T.A 2019', '2019-08-12', '2019-08-12', '', ''),
(57, '800/687/04/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'ASN Yang Di Tugaskan', 'Surat Tugas', '2019-08-12', '2019-08-12', '', ''),
(58, '800/699/ST/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', '-', 'Mendata/Koordinasi Sistem Aplikasi Online Yang Akan Terintegrasi dengan Sertifikat Elektronik', '2019-08-15', '2019-08-15', '', ''),
(59, '045/698.1/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum Sekda Prov. Sumsel', 'Penyampaian Kembali Rancangan Keputusan Gubernur Yang Telah Di Perbaiki', '2019-08-15', '2019-08-15', '', ''),
(60, '045/749/04/Tiksan/2019', 'Kepala Bidang TIK dan Persandian', 'Kadis Kominfo Prov. Sumsel', 'Usul Kegiatan Bidang TIK dan Persandian Tahun 2020', '2019-09-04', '2019-09-04', '', ''),
(61, '045/787/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Persetujuan Kegiatan Kontra Penginderaan', '2019-09-17', '2019-09-17', '', ''),
(62, '045/793/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Kepala Biro Hukum dan HAM', 'Pengembalian Rancangan Keputusan Gubernur Yang Telah Di Bubuhi Paraf Koordinasi', '2019-09-19', '2019-09-19', '', ''),
(63, '005/032/TEL/2019', 'Sekda Prov. Sumsel', 'Kadis Kominfo Kab./Kota Sumsel', 'Sosialisasi Tentang Kegiatan Standarisasi Dan Sertifikasi Keamanan Modul Sandi Dan Keamanan Perangkat Teknologi Informasi', '2019-07-16', '2019-07-16', '', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `surat_masuk`
--

CREATE TABLE `surat_masuk` (
  `noreg` int(11) NOT NULL,
  `nosurat` varchar(128) DEFAULT NULL,
  `dari` varchar(128) DEFAULT NULL,
  `untuk` varchar(128) DEFAULT NULL,
  `hal` varchar(256) DEFAULT NULL,
  `tgl` date DEFAULT NULL,
  `disposisi` date DEFAULT NULL,
  `pengagenda` varchar(128) DEFAULT NULL,
  `ket` varchar(128) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `surat_masuk`
--

INSERT INTO `surat_masuk` (`noreg`, `nosurat`, `dari`, `untuk`, `hal`, `tgl`, `disposisi`, `pengagenda`, `ket`) VALUES
(1, '800/55/BKD.IV.2019', 'Sekda Prov. Sumsel', 'Kepala OPD dilingkungan Pemprov. Sumsel', 'Laporan Penilaian Prestasi Kerja PNS', '2019-01-09', '2019-01-09', '', ''),
(2, '800/063/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Seluruh ASN Diskominfo Prov. Sumsel', 'Menindaklanjuti surat tentang Prosedur Penyampaian Usulan Tanda Kehormatan Satyalancana Karya Satya', '2019-01-10', '2019-01-10', '', ''),
(3, '-/05/Diskominfo/2019', 'Kepala Bidang Layanan e-Government', 'Kadis Kominfo Prov. Sumsel', 'Pelatihan Simaya dan Aplikasi SPSE versi 4.3', '2019-01-17', '2019-01-17', '', ''),
(4, '046/216/Bangda', 'Dirjen Bina Pembangunan Daerah', 'Kepala BSSN (tembusan) ', 'Penyelenggaraan Urusan Pemerintahan Daerah Bidang Persandian', '2019-01-17', '2019-01-17', '', ''),
(5, '700/053/ITDAPROV.V/2019', 'Inspektur Daerah Provinsi', 'Kepala OPD dilingkungan Pemprov. Sumsel', 'Permintaan Data Reviu Kualitas Belanja, Penyerapan Anggaran, Belanja dan Pelaksanaan PBJ yang DIlaksanakan melalui Tender Tahun Anggaran 2018', '2019-01-17', '2019-01-17', '', ''),
(6, '032/426/SATPOL.PP/2019', 'Satpol PP', 'Kadis Kominfo Prov. Sumsel', 'Penyediaan Jaringan HT', '2019-01-21', '2019-01-21', '', ''),
(7, '555/333/SJ', 'Mendagri', 'Sekda', 'Layanan Video Conference Kementrian Dalam Negeri Tahun Anggaran 2019', '2019-01-22', '2019-01-23', '', ''),
(8, '890/116/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Seluruh ASN dilingkungan Diskominfo Prov. Sumsel', 'Permintaan Nama Calon Peserta Pelatihan Diklat', '2019-01-24', '2019-01-24', '', ''),
(9, '-/05/Diskominfo/2018', 'Kepala Layanan e-Government', 'Kadis Kominfo Prov. Sumsel', 'Mohon Penginputan RUP Bidang', '2019-01-24', '2019-01-25', '', ''),
(10, '-', 'Kasubbag Umum dan Kepegawaian Diskominfo Prov. Sumsel', '-', 'Penetapan Tempat Siswa Praktek Kerja Lapangan (PKL) di Lingkungan Diskominfo Prov. Sumsel', '2019-01-25', '2019-01-25', '', ''),
(11, '800/121.1/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Seluruh ASN Diskominfo Prov. Sumsel', 'Jadwal Pelaksanaan Kegiatan Kediklatan BPSDMD Prov. Sumsel Tahun 2019', '2019-01-28', '2019-01-28', '', ''),
(12, 'R.002/BSSN/D2/KH.01.04/01/2019', 'Kepala BSSN', 'Gubernur', 'Permohonan Pengumpulan Laporan Tahunan Pelaksanaan Kegiatan Persandian UTP Instansi Pemerintah Tahun 2018', '2019-01-31', '2019-02-01', '', ''),
(13, '800/137.1/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Melakukan Perjalanan Dinas ', 'Melakukan Input Data Terlebih Dahulu Pada Aplikasi SPPD e-Sumsel Dengan Melampirkan Beberapa Syarat', '2019-02-01', '2019-02-01', '', ''),
(14, '045/112.2/DISKOMINFO/2019', 'Kadis Kominfo Prov.Sumsel', 'Sekda Prov.Sumsel', 'Penjelasan Layanan Video Conference Kemendagri TA 2019', '2019-02-04', '2019-02-04', '', ''),
(15, 'T.058/BSSN/D2/PP.02.01/02/2019', 'Direktur Proteksi Pemerintah', 'Kadis Kominfo Prov. Sumsel', 'Rapat Kerja Keamanan Informasi Instansi Pemerintahan Tahun 2018', '2019-02-11', '2019-02-11', '', ''),
(16, '046/216/Bangda', 'Kemendagri', 'Gubernur', 'Penyelenggaraan Urusan Pemerintahan Daerah Bidang Persandian', '2019-02-11', '2019-02-11', '', ''),
(17, '349/BSSN/03/KH.01.02/02/2019', 'BSSN', 'Kadis Kominfo Prov. Sumsel', 'Undangan Kegiatan Cyber Security Drill Test', '2019-02-15', '2019-02-15', '', ''),
(18, '555/801/Pusdatin', 'Kemendagri', 'PT. Apl kanusa Lintasarta', 'Penarikan Perangkat Video Conference', '2019-02-18', '2019-02-18', '', ''),
(19, '027/0406/VI/2019', 'Sekda', 'Kepala Organisasi Perangkat Daerah Lingkungan Pemerintah', 'Pelaksanaan Pengadaan Barang/Jasa Tahun Anggaran 2019', '2019-02-20', '2019-02-25', '', ''),
(21, '005/0466/II/2019', 'Sekda', 'Kadis Kominfo Prov. Sumsel', 'Rapat Pembahasan Klarifikasi/Evaluasi Raperda Kota Lubuk Linggau', '2019-02-25', '2019-02-26', '', ''),
(22, '604/BSSN/DL/DL.06.01/02/2019', 'Kepala BSSN', 'Kadis Kominfo Prov. Sumsel (Tembusan)', 'Pemanggilan Peserta Diklat Penjenjangan JFS Muda T. A. 2019', '2019-02-26', '2019-02-26', '', ''),
(23, 'S-419/WPJ.03/2019', 'Kepala Kanwil DJP Sumsel Dan Kep. Bangka Belitung', 'Kadis Kominfo Prov. Sumsel', 'Kewajiban Penyampaian SPT Tahunan Secara E-Filing', '2019-02-27', '2019-02-27', '', ''),
(24, '050/144/DPP-PA/2019', 'Kadis Pemberdayaan Perempuan Dan Perlindungan Anak Prov. Sumsel ', 'Kadis Kominfo Prov. Sumsel', 'Peminjaman Ruang Teleconference Pemerintah Prov. Sumsel', '2019-03-01', '2019-03-04', '', ''),
(25, 'T.017/BSSN/D2/PP.05.01/01/2019', 'Kepala BSSN', 'Gubernur U.P. Sekda', 'Penyampaian Nomenklatur Program Dan Kegiatan Serta Indikator Kinerja Kunci Urusan Persandian', '2019-03-05', '2019-03-05', '', ''),
(26, '67/BPSDMP.31/LT.03.08/3/2019', 'Balai Pengembangan SDM Dan Penelitian Kominfo', 'Kadis Kominfo Prov. Sumsel', 'Undangan Kegiatan SKKNI 2019', '2019-03-06', '2019-03-06', '', ''),
(27, 'B-6/SET/DWP.SS/III/2019', 'Persatuan Dharma Wanita Prov. Sumsel', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Internet Dan Petugas', '2019-03-08', '2019-03-08', '', ''),
(28, '1023/3077/SOC/2019', 'Students Online Competition (SOC)', 'Kadis Kominfo Prov. Sumsel', 'Undangan Pembukaan Kegiatan Students Online Competition (SOC)/Olimpiade Online Siswa', '2019-03-08', '2019-03-08', '', ''),
(29, '050/0373/Bappeda-V/2019', 'Kepala Bappeda Prov. Sumsel', 'Kepala Perangkat Daerah di Lingkungan Pemprov. Sumsel', 'Penyampaian Rencana Kerja Perangkat Daerah Tahun 2020', '2019-03-12', '2019-03-12', '', ''),
(30, '005/0458/Bappeda-V/2019', 'Kepala Bappeda Prov. Sumsel', 'Kepala Perangkat Daerah di Lingkungan Pemprov. Sumsel', 'Pembahasan Rencana Kerja Perangkat Daerah Tahun 2020', '2019-03-18', '2019-03-18', '', ''),
(31, '339/208/V.2/XXX/2019', 'Kominfo Oku', 'Kadis Kominfo Prov. Sumsel', 'Permohonan Sterilisasi/Kontra Penginderaan', '2019-03-18', '2019-09-19', '', ''),
(32, '046/PA/Diskominfo-IV/2019', 'Bupati Muara Enim', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Tim Strerilisasi ', '2019-03-18', '2019-09-19', '', ''),
(33, 'B-II/SET/DWP.SS/III/2019', 'Persatuan Dharma Wanita Prov. Sumsel', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Internet Dan Petugas', '2019-03-18', '2019-03-19', '', ''),
(34, '726/DL/03/2019', 'Kepala BSSN', 'Calon Peserta Pendidikan Dan Pelatihan Penjejangan Fungsional Sandiman Muda', 'Surat Perintah Bagi Calon Peserta Pelatihan Yang Dimaksud', '2019-03-19', '2019-03-19', '', ''),
(35, '555/1444/SJ', 'Sekjen Kemendagri', 'Sekda Prov.', 'Pemanfaatan Layanan Video Conference', '2019-03-20', '2019-03-20', '', ''),
(36, '1002/BSSN/D2/KH.01.02/03/2019', 'Kepala BSSN', 'Kadis Kominfo Prov./Kab/Kota', 'Tata Cara Konsultasi Pemerintah Daerah Urusan Persandian', '2019-03-22', '2019-03-22', '', ''),
(37, 'T.152/BSSN/D2/PP.01.01/03/2019', 'Kepala BSSN', 'Kadis Kominfo Prov. Sumsel', 'Penyampaian Laporan Hasil Executive Summary Rapat Kerja Keamanan Informasi', '2019-03-25', '2019-03-25', '', ''),
(38, '0671/005/Diskominfo/2019', 'Sekda Asisten Administrasi Dan Umum', '(Daftar Terlampir)', 'Undangan', '2019-03-25', '2019-03-25', '', ''),
(39, '555/2474/SJ', 'Mendagri', 'Gubernur', 'Pemanfaatan Layanan Komunikasi Video Conference', '2019-03-26', '2019-03-27', '', ''),
(40, '1002/BSSN/D2/KH.01.02/03/2019', 'Kepala BSSN', 'Kadis Kominfo Prov./Kab/Kota', 'Tata Cara Konsultasi Pemerintah Daerah Urusan Persandian', '2019-03-26', '2019-03-27', '', ''),
(41, '016/SE/PERIND/2019', 'Gubernur Sumsel', 'Pimpinan Instansi Pemerintah/Swasta Sumsel', 'Penggunaan Produk Pempek Palembang', '2019-04-02', '2019-04-04', '', ''),
(42, '890/00626/BPSDMD/II/2019', 'Kepala BPSDMD', 'Kepala OPD Prov. Sumsel', 'Permintaan Nama Peserta Diklat TOC Tahun 2019', '2019-04-02', '2019-04-02', '', ''),
(43, '005/189/ITDAPROV.V.2/2019', 'Inspektur Daerah Prov. Sumsel', 'Kepala OPD Prov. Sumsel ', 'Pelaksanaan Pengawasan Penyelenggaraan Pemerintah Daerah Tahun 2019', '2019-04-04', '2019-04-04', '', ''),
(44, '001/KASA/M/2019', 'Kemendagri', 'Kadiskominfo', '-', '2019-04-05', '2019-04-05', '', ''),
(45, '900/72/TU/VI/2019', 'Sekda', 'Kepala Organisasi Perangkat Daerah Lingkungan Pemerintah Prov. Sumsel', 'Percepatan Pelaksanaan Pengadaan Barang/Jasa', '2019-04-05', '2019-04-08', '', ''),
(46, '010/SE/Dispora/2019', 'Gubernur Sumsel', 'Ketum KONI; Ketua Asosiasi PSSI Prov. Sumsel', 'Pembentukan TIM Sepak Bola Organisasi Perangkat Daerah Di Lingkungan Pemerintah Prov. Sumsel', '2019-04-06', '2019-04-06', '', ''),
(47, '555/2908/SJ', 'Sekjen Kepala Pusat Data dan Sistem Informasi', 'Sekda Prov.', 'Jadwal Pelaksanaan Uji Coba Video Conference', '2019-04-08', '2019-04-08', '', ''),
(48, '005/276/01/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', 'Daftar Terlampir', 'Undangan Rapat', '2019-04-08', '2019-04-08', '', ''),
(49, '273/2887/SJ', 'Kemendagri', 'Gubernur', 'Pelaksanaan Video Conference Antara Kemendagri dan Pemerintah Prov. Seluruh Indonesia', '2019-04-08', '2019-04-08', '', ''),
(50, '555/2908/SJ', 'Sekjen Kemendagri', 'Sekda Prov.', 'Jadwal Pelaksanaan Uji Coba Conference', '2019-04-08', '2019-04-08', '', ''),
(51, '050/321/1.1/XXX/2019', 'Kadis Kominfo Oku', 'Gubernur Sumsel; Kadis Kominfo Prov. Sumsel', 'Usulan K/L Dinas Kominfo Kabupaten OKU Melalui Aplikasi ', '2019-04-10', '2019-04-10', '', ''),
(52, '005/340/ITDAPROV.V.2/2019', 'Sekda Prov.', 'Kepala OPD Prov. Sumsel', 'Penyampaian Hasil Identifikasi, Penyusunan dan Pengendalian Peta Risiko OPD Tahun 2019', '2019-04-11', '2019-04-11', '', ''),
(53, '005.A/UND/ISI//IV/2019', 'Ketum Ikatan Sandiman Indonesia', 'Kadis Kominfo Prov. Sumsel', 'Undangan Seminar Nasional Ke-1 Ikatan Sandiman Indonesia', '2019-04-22', '2019-04-22', '', ''),
(54, 'T.250/BSSN/03/PP.01.02/04/2019', 'Kepala BSSN', 'Sekda Prov. Sumsel', 'Penyampaian Jadwal Kegiatan Asistensi Pembentukan CSIRT Sektoral di Lingkungan Pemda T.A 2019', '2019-04-23', '2019-04-23', '', ''),
(55, '046/170/Diskominfo/2019', 'Diskominfo OKI', 'Kadis Kominfo Prov. Sumsel', 'Mohon Bantuan Tim Sentralisasi', '2019-04-23', '2019-04-23', '', ''),
(56, '-', 'Waka Kesiswaan SMK N 2 PLG', 'Diskominfo', 'Dispensasi', '2019-04-25', '2019-04-25', '', ''),
(57, '-', 'Waka Kesiswaan SMKN 2 PLG', 'Diskominfo', 'Dispensasi', '2019-04-25', '2019-04-25', '', ''),
(58, '555.4/3620/SJ', 'Mendagri', 'Sekda Prov.', 'Pemberitahuan Website dan Media Sosial Resmi Kemendagri', '2019-05-09', '2019-05-09', '', ''),
(59, '90/PA.RA/IV/2019', 'Pengurus Panti Asuhan Rido Anugerah', 'Pimpinan Diskominfo Prov. Sumsel', 'Permohonan Bantuan Zakat Mal atau Zakat Fitrah dan Kebutuhan Pokok Lainnya Untuk Anak Asuh PA Rido Anugerah', '2019-05-16', '2019-05-16', '', ''),
(60, '1496/BSSN/02/PP.01.01/05/2019', 'Kepala BSSN', 'Gubernur Sumsel', 'Pemanfaatan Alat Kontra Penginderaan Oleh Pemerintah Kab/Kota', '2019-05-16', '2019-05-16', '', ''),
(61, '1764/BSSN/03/KH.01.02/OE/2019', 'BSSN', 'Gubernur', 'Undangan Kegiatan Focus Group Discussion (FGD)', '2019-06-18', '2019-06-18', '', ''),
(62, '000/434/VI/K/2019', 'Kadis Kominfo Kota Palembang', 'Kadis Kominfo Prov. Sumsel', 'Bantuan Kontra Penginderaan', '2019-06-18', '2019-06-18', '', ''),
(63, '1849/BSSN/DL/DL.06.05/06/2019', 'BSSN', 'Sekda Prov. Sumsel', 'Pemberitahuan Kegiatan Evaluasi Pascadiklat', '2019-06-26', '2019-06-26', '', ''),
(64, 'T.526/BSSN/DU/PP.01.02/06/2019', 'Kepala BSSN', 'Gubernur', 'Rencana Kegiatan Pengendalian Peredaran dan Evaluasi Modul Sandi dan Keamanan Perangkat Teknologi Informasi', '2019-06-27', '2019-06-27', '', ''),
(65, '1849/BSSN/DL/DL.06.05/06/2019', 'BSSN', 'Kadis Kominfo Prov. Sumsel', 'Pemberitahuan Kegiatan Evaluasi Pascadiklat', '2019-06-28', '2019-07-01', '', ''),
(66, 'FT.118/KASA-BSSN/06/2019', 'Kepala BSSN', 'Gubernur', 'Rencana Kegiatan Pengendalian Peredaran dan Evaluasi Modul Sandi dan Keamanan Perangkat Teknologi Informasi', '2019-07-10', '2019-07-10', '', ''),
(67, '-', 'Kepala Sub Bagian Umum dan Kepegawaian Diskominfo', '-', 'Peneteapan Tempat Peserta Magang/Prakerin di Lingkungan Diskominfo Prov. Sumsel', '2019-07-01', '2019-07-01', '', ''),
(68, '043/SE/Diskominfo/2019', 'Gubernur', 'Kepala OPD; Kepala Biro', 'Penyelenggaraan Festival Gapura Cinta Negeri Tahun 2019 ', '2019-07-18', '2019-07-18', '', ''),
(69, '900/297/PBJ/VI/2019', 'Gubernur', 'Kadis Kominfo Prov. Sumsel', 'Sterilisasi Ruangan Kerja', '2019-08-07', '2019-08-07', '', ''),
(70, '2129/BSSN/03/KH.02.02/2019', 'Kepala BSSN', 'Gubernur', 'Hasil Focus Group Discussion (FGD) Sektor Pemerintahan Tahun 2019', '2019-08-15', '2019-08-15', '', ''),
(71, 'S.541/MENLHK/SETJEN/PSL.3/8/2019', 'Menteri Lingkungan Hidup Dan Kehutanan', 'Diskominfo', 'Perkemahan Bakti Saka Kalpataru dan Saka Wanabakti Tingkat Nasional Tahun 2019', '2019-08-19', '2019-08-19', '', ''),
(72, '005/0980/Diskominfo-IV/2019', 'Bupati Muara Enim', 'Kadis Kominfo Prov. Sumsel', 'Undangan Pembukaan', '2019-09-04', '2019-09-04', '', ''),
(73, '100/434/Diskominfo/2019', 'Walikota Pagar Alam', 'Sekda Prov. Sumsel', 'Permohonan Bantuan Tim Sterilisasi', '2019-09-17', '2019-09-17', '', ''),
(74, '046/4048/Pusdatin', 'Kemendagri', 'Gubernur', 'Pemberitahuan Calon Peserta Diklat Pembentukan Sandi Pusdiklat BSSN', '2019-09-17', '2019-09-17', '', ''),
(75, 'R.790/BSSN/D2/PP.01.02/09/2019', 'BSSN', 'Kadis Kominfo Prov. Sumsel', 'Pemantauan Tindak Lanjut Rekomendasi Hasil Audit Keamanan Informasi', '2019-09-25', '2019-09-25', '', ''),
(76, '800/2695/BKD.Sekr/2019', 'Kepala Badan Kepegawaian Daerah', 'Kadis Kominfo Prov. Sumsel', 'Permohonan Kontra Penginderaan Sterilisasi Ruang Pimpinan, Ruang Rapat Serta Ruang Pejabat Eselon III', '2019-08-28', '2019-08-28', '', ''),
(77, 'T.526/BSSN/D4/PP.01.02/06/2019', 'Kepala BSSN', 'Gubernur', 'Rencana Kegiatan Pengendalian Peredaran dan Evaluasi Modul Sandi dan Keamanan Perangkat Teknologi Informasi', '2019-06-27', '2019-06-27', '', ''),
(78, '2375/BSSN/DI/KH.02.01/08/2019', 'BSSN', 'Kadis Kominfo Prov. Sumsel', 'Permohonan Sharing Informasi Mengenai Pemanfaatan Ruang Siber di Prov. Sumsel', '2019-08-28', '2019-09-04', '', ''),
(79, 'S.KEP.146/03/Diskominfo/2019', 'Kadis Kominfo Prov. Sumsel', '-', 'Pembentukan Panitia Pelaksana Kegiatan Pameran Sriwijaya EXPO Prov. Sumsel T.A 2019', '2019-07-10', '2019-07-10', '', ''),
(80, '800/2695/BKD.Sekr/2019', 'BKD Prov. Sumsel', 'Kadis Kominfo Prov. Sumsel', 'Permohonan Kontra Penginderaan Sterilisasi Ruang Pimpinan, Ruang Rapat Serta Ruang Pejabat Eselon III', '2019-08-27', '2019-09-04', '', ''),
(81, '900/2539/BPKAD-11/2019', 'Sekda Prov. Sumsel', 'Kepala Dinas/Badan/Satuan Kerja di Lingkungan Pemerintah Prov. Sumsel', 'Penggunaan program/kegiatan barang yang diserahkan kepada masyarakat/pihak ketiga', '2019-10-04', '2019-10-07', '', ''),
(82, '046/4598/Pusdatin', 'Kemendagri RI', 'Kadis Kominfo Prov.Sumsel', 'Pemutakhiran Data Persandian', '2019-10-07', '2019-10-07', '', ''),
(83, '045/787/04/DISKOMINFO/2019', 'Kadis Kominfo Prov. Sumsel', 'Sekda Prov. Sumsel', 'Mohon Persetujuan Kegiatan Kontra Penginderaan', '2019-09-24', '2019-10-03', '', ''),
(84, '046/406/Diskominfo-IV/2019', 'Bupati Muara Enim', 'Sekda Prov. Sumsel', 'Mohon Bantuan Tim Sterilisasi', '2019-10-03', '2019-10-04', '', ''),
(85, '046/ 329/ Kominfo-VII/ 2019', 'Bupati Lahat', 'Kepala Dinas Kominfo Sumatera Selatan', 'mohon bantuan sterilisasi', '2019-09-05', '2019-09-15', 'eka', ''),
(86, '3119/ BSSN/ D3/ KH.02.01/ 10/ 2019', 'Deputi GULIH BSSN', 'Kepala Dinas Kominfo Sumatera Selatan', 'Undangan Kegiatan Cyber security Drill test II ', '2019-10-07', '2019-10-14', 'eka', ''),
(87, 'T.849/ BSSN/ D2/ PP.01.02/ 10/ 2019', 'Direktur Proteksi BSSN', 'Kepala Dinas Kominfo Sumatera Selatan', 'Distribusi Jammer PBJ 630', '2019-10-07', '2019-10-10', 'eka', ''),
(88, 'R.857/ BSSN/ D1/ PP.01.02/ 10/ 2019', 'Direktur Proteksi BSSN', 'Kepala Dinas Kominfo Sumatera Selatan', 'Lap hasil Pelaksanaan Keg Operasi  Deteksi Ancaman Sosiokultural di wilayah Sumatera Selatan', '2019-10-09', '2019-10-14', 'eka', ''),
(89, '046/11474/ SJ', 'Sekjen Kemendagri', 'Sekretaris Daerah Prov. Sumatera Selatan', 'Jadwal Pelaksanaan Monitoring dan Evaluasi Vidcon', '2019-10-21', '2019-10-23', 'eka', ''),
(90, '3300/ BSSN/ D2/KH.01.02/ 10/ 2019', 'Deputi Bidang Proteksi BSSN', 'Kadis Kominfo  Sumatera Selatan', 'Undangan FGD Uji Publik Peraturan BSSN tentang Penyelenggaraan VVDP', '2019-10-18', '2019-10-18', 'eka', ''),
(91, '3871/BSSN/SU/KH.02.01/11/ 2019', 'Karo Hukum dan Humas BSSN', 'Kepala Dinas Kominfo Sumatera Selatan', 'Undangan Rapat Finalisasi Penandatangan PKS', '2019-11-19', '2019-11-22', 'eka', ''),
(92, '037/UND/ISI/XII/2019', 'Ketua Umum Ikatan Sandiman Indoensia', 'Kepala Dinas Kominfo Sumatera Selatan', 'Ralat Undangan Rapat Kerjasama dan Syukuran HUT ke 11 Ikatan Sandiman Indoensia', '2019-12-18', '2019-12-18', 'eka', ''),
(93, '555/ IV/ 00927', 'Kadis Bapenda Sumsel', 'Kepala Dinas Kominfo Sumatera Selatan', 'Bantuan Kegiatan Kontra Penginderaan', '2019-10-14', '2019-10-18', 'eka', ''),
(94, '470/502/Disdukcapil.V/ 2019', 'Kadis Dukcapil Prov. Sumsel', 'Kadis Kominfo  Sumsel', 'Permintaan Narasumber', '2019-11-12', '2019-11-14', 'eka', ''),
(95, '036/SE/IX/2019', 'Gubernur Sumatera Selatan', 'Kepala OPD Sumsel', 'Publikasi kegiatan Pemprov melalui Medsos ', '2019-05-24', '2019-10-10', 'Eka', ''),
(96, '049/647/DPKP/ 2019', 'Kadis Perumahan dan Kawasan Permukiman', 'Kepala Dinas Kominfo Sumatera Selatan', 'Permohonan Kegiatan Kontra Penginderaan ', '2019-11-07', '2019-11-08', 'Eka', ''),
(97, '900/0318/ BPKAD-I/ 2019', 'Kepala Dinas BPKAD Sumatera Selatan', 'Kepala Dinas Kominfo Sumatera Selatan', 'Pendataan  Aplikasi Sistem Online', '2019-10-09', '2019-10-10', 'Eka', ''),
(98, '800/ 695/ 01/ Diskominfo 2019', 'Sekdin Kominfo Sumatera Selatan', 'Kasi Persandian', 'Surat Tugas Upacara an. Wiyasmoro,ST', '2019-08-14', '2019-08-14', 'Ek', ''),
(99, '5323/ Ass I/ 2019', 'Gubernur Sumatera Selatan', 'Kepala Dinas Kominfo Sumatera Selatan', 'Rapat Persiapan Acara Dunia Melayu Dunia Islam', '2019-11-14', '2019-11-14', 'Eka', ''),
(100, '188.342/ 3426/ 2019', 'Gubernur Sumatera Selatan', 'Kepala Dinas Kominfo Sumatera Selatan', 'Fasilitasi Rancangan Peraturan Walikota Sumatera Selatan', '2019-12-27', '2019-12-31', 'Ek', '');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `laporan_harian`
--
ALTER TABLE `laporan_harian`
  ADD PRIMARY KEY (`no`);

--
-- Indeks untuk tabel `radiogram`
--
ALTER TABLE `radiogram`
  ADD PRIMARY KEY (`noreg`);

--
-- Indeks untuk tabel `surat_keluar`
--
ALTER TABLE `surat_keluar`
  ADD PRIMARY KEY (`noreg`);

--
-- Indeks untuk tabel `surat_masuk`
--
ALTER TABLE `surat_masuk`
  ADD PRIMARY KEY (`noreg`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `laporan_harian`
--
ALTER TABLE `laporan_harian`
  MODIFY `no` int(100) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
